

# default['ID-MonitoringAgents']['filebeat']['windows']['base_url'] = "https://artifacts.elastic.co/downloads/beats/filebeat/"
# default['ID-MonitoringAgents']['filebeat']['windows']['version'] = "7.0.0"
# default['ID-MonitoringAgents']['filebeat']['windows']['architecture'] = "x86_64"
# default['ID-MonitoringAgents']['filebeat']['windows']['filename'] = "filebeat-%{version}-windows-%{architecture}.zip"
# default['ID-MonitoringAgents']['filebeat']['windows']['download_url'] = ""

#============== Filebeat ===================
default['ID-MonitoringAgents']['filebeat']['debian'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/apt",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "version" => "7.0.0"
}

default['ID-MonitoringAgents']['filebeat']['rhel'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/yum",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "architecture" => "x86_64",
  "version" => "7.0.0-1"
}

default['ID-MonitoringAgents']['filebeat']['windows'] = {
  "base_url" => "https://artifacts.elastic.co/downloads/beats/filebeat",
  "version" => "7.0.0",
  "architecture" => "x86_64",
  "filename" => "filebeat-%{version}-windows-%{architecture}.zip",
  "download_url" => "%{base_url}/%{filename}"
}

#============== Heartbeat ===================
default['ID-MonitoringAgents']['heartbeat']['debian'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/yum",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "version" => "7.0.0"
}

default['ID-MonitoringAgents']['heartbeat']['rhel'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/yum",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "architecture" => "x86_64",
  "version" => "7.0.0-1"
}

default['ID-MonitoringAgents']['heartbeat']['windows'] = {
  "base_url" => "https://artifacts.elastic.co/downloads/beats/heartbeat",
  "version" => "7.0.0",
  "architecture" => "x86_64",
  "filename" => "heartbeat-%{version}-windows-%{architecture}.zip",
  "download_url" => "%{base_url}/%{filename}"
}

#============== Metricbeat ===================
default['ID-MonitoringAgents']['metricbeat']['debian'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/yum",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "version" => "7.0.0-1"
}

default['ID-MonitoringAgents']['metricbeat']['rhel'] = {
  "repo_url" => "https://artifacts.elastic.co/packages/7.x/yum",
  "gpgkey_url" => "https://artifacts.elastic.co/GPG-KEY-elasticsearch",
  "architecture" => "x86_64",
  "version" => "7.0.0-1"
}

default['ID-MonitoringAgents']['metricbeat']['windows'] = {
  "base_url" => "https://artifacts.elastic.co/downloads/beats/metricbeat",
  "version" => "7.0.0",
  "architecture" => "x86_64",
  "filename" => "metricbeat-%{version}-windows-%{architecture}.zip",
  "download_url" => "%{base_url}/%{filename}"
}

#============== NodeExporter ===================
default['ID-MonitoringAgents']['node_exporter']['debian'] = {
  "port": "9100",
  "base_url" => "https://github.com/prometheus/node_exporter/releases/download",
  "version" => "0.17.0",
  "architecture" => "amd64",
  "filename" => "node_exporter-%{version}.linux-%{architecture}.tar.gz",
  "download_url" => "%{base_url}/v%{version}/%{filename}"
}

default['ID-MonitoringAgents']['node_exporter']['rhel'] = {
  "port": "9100",
  "base_url" => "https://github.com/prometheus/node_exporter/releases/download",
  "version" => "0.17.0",
  "architecture" => "amd64",
  "filename" => "node_exporter-%{version}.linux-%{architecture}.tar.gz",
  "download_url" => "%{base_url}/v%{version}/%{filename}"
}

# node_exorpter equivalent for Windows is wmi_exporter
default['ID-MonitoringAgents']['wmi_exporter']['windows'] = {
  "port": "9182",
  "base_url" => "https://github.com/martinlindhe/wmi_exporter/releases/download",
  "version" => "0.5.0",
  "architecture" => "amd64",
  "filename" => "wmi_exporter-%{version}-%{architecture}.msi",
  "download_url" => "%{base_url}/v%{version}/%{filename}"
}

#============== Dynatrace OneAgent ===================
# You can't install a specific version of Dynatrace
# Always the latest version is installed
# cf. https://answers.dynatrace.com/answers/189030/view.html

default['ID-MonitoringAgents']['oneagent']['debian'] = {
  "host" => "https://ell97466.live.dynatrace.com",
  "version" => "latest",
  "base_url" => "%{host}/api/v1/deployment/installer/agent/unix/default/latest",
  "filename" => "Dynatrace-OneAgent-Linux.sh",
  "download_params" => {
    "api_token" => "xxxxx", # Stored in encrypted data bag
    "architecture" => "x64",
    "flavor" => "default"
  },
  "install_params" => "APP_LOG_CONTENT_ACCESS=1 INFRA_ONLY=0"
}

default['ID-MonitoringAgents']['oneagent']['rhel'] = {
  "host" => "https://ell97466.live.dynatrace.com",
  "version" => "latest", # e.g. "1.157.210"
  "base_url" => "%{host}/api/v1/deployment/installer/agent/unix/default/latest",
  "filename" => "Dynatrace-OneAgent-Linux.sh",
  "download_params" => {
    "api_token" => "xxxxx", # Stored in encrypted data bag
    "architecture" => "x64",
    "flavor" => "default"
  },
  "install_params" => "APP_LOG_CONTENT_ACCESS=1 INFRA_ONLY=0",
  "signature_verification" => false,
  "signature_filename" => "dt-root.cert.pem",
  "signature_host" => "https://ca.dynatrace.com",
  "signature_content_type" => "multipart/signed",
  "signature_protocol" => "application/x-pkcs7-signature",
  "signature_micalg" => "sha-256",
  "signature_boundary" => "--SIGNED-INSTALLER"
}

default['ID-MonitoringAgents']['oneagent']['windows'] = {
  "host" => "https://ell97466.live.dynatrace.com",
  "version" => "latest",
  "base_url" => "%{host}/api/v1/deployment/installer/agent/windows/default-unattended/latest",
  "filename" => "Dynatrace-OneAgent-Windows.zip",
  "download_params" => {
    "api_token" => "xxxxx", # Stored in encrypted data bag
    "architecture" => "x64",
    "flavor" => "default"
  },
  "is_prod_env" => false,
  "install_params" => "APP_LOG_CONTENT_ACCESS=1 INFRA_ONLY=0"
}
