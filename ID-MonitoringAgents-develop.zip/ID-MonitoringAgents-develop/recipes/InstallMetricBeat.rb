#
# Cookbook:: ID-MonitoringAgents
# Recipe:: InstallMetricBeat
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

#============== Metricbeat ===================
# Install MetricBeat

include_recipe '::SetupMonitoring'

case node['platform_family']
when 'debian'

  apt_package "metricbeat" do
    version node['ID-MonitoringAgents']['metricbeat']['debian']['version']
    action :install
  end

  service "metricbeat" do
    action [:enable]
  end

when 'rhel'
  yum_package "metricbeat" do
    version node['ID-MonitoringAgents']['metricbeat']['rhel']['version']
    action :install
  end

  service "metricbeat" do
    action [:enable]
  end

when 'windows'

  tmp_directory = "C:\\temp"

  directory "create-temp-directory" do
   path tmp_directory
  end

  metricbeat_filename = node['ID-MonitoringAgents']['metricbeat']['windows']['filename'] % {
    version: node['ID-MonitoringAgents']['metricbeat']['windows']['version'],
    architecture: node['ID-MonitoringAgents']['metricbeat']['windows']['architecture']
  }
  metricbeat_dl_path = "C:\\temp\\#{metricbeat_filename}"
  remote_file metricbeat_dl_path do
    source node['ID-MonitoringAgents']['metricbeat']['windows']['download_url'] % {
      base_url: node['ID-MonitoringAgents']['metricbeat']['windows']['base_url'],
      filename: metricbeat_filename
    }
    action :create
  end

  metricbeat_program_path = "C:\\Program Files\\Metricbeat"

  directory "create-program-files-directory-for-metricbeat" do
   path metricbeat_program_path
  end

  powershell_script "unzip-file-#{metricbeat_filename}" do
    code <<-EOH
     expand-Archive "#{metricbeat_dl_path}" "#{tmp_directory}"
     EOH
    only_if { ::File.extname("#{metricbeat_dl_path}") == '.zip' }
  end

  powershell_script "unzip-file-#{metricbeat_filename}" do
    code <<-EOH
     move-Item -Path "#{tmp_directory}\\#{metricbeat_filename.gsub(".zip","")}\\*" -Destination "#{metricbeat_program_path}"
     EOH
    only_if { ::Dir.empty?("#{metricbeat_program_path}") }
  end

  #ExecutionPolicy UnRestricted -File "#{metricbeat_program_path}\install-service-metricbeat.ps1"
  powershell_script 'install-metricbeat' do
    code <<-EOH
    . "#{metricbeat_program_path}\\install-service-metricbeat.ps1"
    EOH
    only_if { ::File.exist?("#{metricbeat_program_path}\\install-service-metricbeat.ps1") }
  end

end
