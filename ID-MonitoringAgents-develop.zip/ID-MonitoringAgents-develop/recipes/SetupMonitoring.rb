#
# Cookbook:: ID-MonitoringAgents
# Recipe:: SetupMonitoring
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

case node['platform_family']
  when 'debian'

    packages = ['wget', 'apt-transport-https']

    packages.each do |pkg|
      apt_package "install-#{pkg}" do
        package_name pkg
        action :install
      end
   end

    execute 'retrieve-GPG-KEY-for-elasticsearch-repo' do
      user 'root'
      group 'root'
      command "wget -qO - #{node['ID-MonitoringAgents']['filebeat']['debian']['gpgkey_url']} | sudo apt-key add -"
    end

    apt_repository 'elastic' do
      uri  node['ID-MonitoringAgents']['filebeat']['debian']['repo_url']
      key node['ID-MonitoringAgents']['filebeat']['debian']['gpgkey_url']
      components ['stable', 'main']
      action :add
    end

   when 'rhel'
    execute 'retrieve-GPG-KEY-for-elasticsearch-repo' do
      user 'root'
      group 'root'
      command "rpm --import #{node['ID-MonitoringAgents']['filebeat']['rhel']['gpgkey_url']}"
    end

  	yum_repository "elastic" do
  		description "Elastic repository for 7.x packages"
  		baseurl node['ID-MonitoringAgents']['filebeat']['rhel']['repo_url']
  		gpgkey node['ID-MonitoringAgents']['filebeat']['rhel']['gpgkey_url']
  		enabled true
      action :create
  	end

   when 'windows'
     Chef::Log.info "Nothing special to do on Windows platform. The install of required component is managed in the Install{Component} recipe."

  else
   raise "Operating system '#{node['platform_family']}' not supported (possible values are 'debian', 'rhel' or 'windows')"

end
