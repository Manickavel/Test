#
# Cookbook:: ID-MonitoringAgents
# Recipe:: InstallDynatrace
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

#============== Dynatrace OneAgent ===================
# Install Dynatrace OneAgent

# Get Dynatrace API token (ID-ServiceDeliveryHelper)
dynatrace_credentials = get_dynatrace_credentials
api_token = dynatrace_credentials['api_token']

case node['platform_family']
when 'debian'

  oneagent_filename = node['ID-MonitoringAgents']['oneagent']['debian']['filename']
  install_params = node['ID-MonitoringAgents']['oneagent']['debian']['install_params']

  oneagent_version = node['ID-MonitoringAgents']['oneagent']['debian']['version']
  Chef::Log.info("oneagent_version: #{oneagent_version}")

  if oneagent_version == "latest"
    # then download from TENANT.dynatrace.com

    # Prepare URL parameters
    download_params = "Api-Token=%{api_token}&arch=%{architecture}&flavor=%{flavor}" % {
      api_token: api_token,
      architecture: node['ID-MonitoringAgents']['oneagent']['debian']['download_params']['architecture'],
      flavor: node['ID-MonitoringAgents']['oneagent']['debian']['download_params']['flavor']
    }
    # Full URL wih parameters
    download_url = "#{node['ID-MonitoringAgents']['oneagent']['debian']['base_url']}?#{download_params}" % {
      host: node['ID-MonitoringAgents']['oneagent']['debian']['host']
    }

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "/tmp/#{oneagent_filename}" do
      source download_url
      action :create
    end
    
  else
    # then Download from Nexus
    nexus_credentials = get_nexus_credentials
    encoded_basic_auth = encode_basic_auth_credentials nexus_credentials
    nexus_host = node['ID-ServiceDeliveryHelper']['repository']['base_url']
    nexus_path = "sd-raw-hosted-application/agents/dynatrace/Dynatrace-OneAgent-Linux-#{oneagent_version}.sh"
    # Full URL
    download_url = "#{nexus_host}/#{nexus_path}"

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "/tmp/#{oneagent_filename}" do
      source download_url
      headers( "Authorization"=>"Basic #{encoded_basic_auth}" )
      action :create
    end
    
  end

  # Install package
  bash "install-oneagent" do
    cwd '/tmp/'
    code <<-EOH
      /bin/sh #{oneagent_filename} #{install_params}
    EOH
  end

  ## To uninstall run:
  # /opt/dynatrace/oneagent/agent/uninstall.sh

when 'rhel'

  oneagent_filename = node['ID-MonitoringAgents']['oneagent']['rhel']['filename']
  install_params = node['ID-MonitoringAgents']['oneagent']['rhel']['install_params']
  verify_signature = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_verification']
  

  oneagent_version = node['ID-MonitoringAgents']['oneagent']['rhel']['version']
  Chef::Log.info("oneagent_version: #{oneagent_version}")

  if oneagent_version == "latest"
    # then download from TENANT.dynatrace.com

    # Prepare URL parameters
    download_params = "Api-Token=%{api_token}&arch=%{architecture}&flavor=%{flavor}" % {
      api_token: api_token,
      architecture: node['ID-MonitoringAgents']['oneagent']['rhel']['download_params']['architecture'],
      flavor: node['ID-MonitoringAgents']['oneagent']['rhel']['download_params']['flavor']
    }
    # Full URL wih parameters
    download_url = "#{node['ID-MonitoringAgents']['oneagent']['rhel']['base_url']}?#{download_params}" % {
      host: node['ID-MonitoringAgents']['oneagent']['rhel']['host']
    }

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "/tmp/#{oneagent_filename}" do
      source download_url
      action :create
    end
    
  else
    # then Download from Nexus
    nexus_credentials = get_nexus_credentials
    encoded_basic_auth = encode_basic_auth_credentials nexus_credentials
    nexus_host = node['ID-ServiceDeliveryHelper']['repository']['base_url']
    nexus_path = "sd-raw-hosted-application/agents/dynatrace/Dynatrace-OneAgent-Linux-#{oneagent_version}.sh"
    # Full URL
    download_url = "#{nexus_host}/#{nexus_path}"

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "/tmp/#{oneagent_filename}" do
      source download_url
      headers( "Authorization"=>"Basic #{encoded_basic_auth}" )
      action :create
    end
    
  end
  
  #Signature Verification

  signature_content_type = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_content_type']
  signature_host = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_host']
  signature_protocol = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_protocol']
  signature_micalg = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_micalg']
  signature_boundary = node['ID-MonitoringAgents']['oneagent']['rhel']['signature_boundary']

  if verify_signature == true
    signature_download_url = "#{signature_host}/#{signature_filename}"
    status =""
    
    # Download signature file
    remote_file "/tmp/#{signature_filename}" do
      source signature_download_url
      headers( "Authorization"=>"Basic #{encoded_basic_auth}" )
      action :create
    end
    
    #Verify Signature
    bash "verify-signature" do
      cwd '/tmp/'
      code <<-EOH
        /bin/sh ( echo 'Content-Type:#{signature_content_type}; protocol=\"#{signature_protocol}\"; micalg=\"#{signature_micalg}\"; boundary=\"#{signature_boundary}\"'; echo ; echo ; echo '----SIGNED-INSTALLER' ; cat #{oneagent_filename} ) | openssl cms -verify -CAfile #{signature_filename} > /dev/null 2>/tmp/out
      EOH
    end
    status = File.read("/tmp/out")
    if status.strip() != "Verification successful"
      STDERR.puts("ABORTED! Signature Verification Failed.")
      exit(false)
    end
  end  

  # Install package
  bash "install-oneagent" do
    cwd '/tmp/'
    code <<-EOH
      /bin/sh #{oneagent_filename} #{install_params}
    EOH
  end

  ## To uninstall run:
  # /opt/dynatrace/oneagent/agent/uninstall.sh


when 'windows'

  # Create temp dir if not exists
  tmp_directory = "C:\\temp"
  directory "create-temp-dir" do
    path tmp_directory    
  end

  oneagent_filename = node['ID-MonitoringAgents']['oneagent']['windows']['filename']
  install_params = node['ID-MonitoringAgents']['oneagent']['windows']['install_params']

  oneagent_version = node['ID-MonitoringAgents']['oneagent']['windows']['version']
  is_prod_env = node['ID-MonitoringAgents']['oneagent']['windows']['is_prod_env']
  Chef::Log.info("oneagent_version: #{oneagent_version}")

  if oneagent_version == "latest"
    # then download from TENANT.dynatrace.com

    # Prepare URL parameters
    download_params = "Api-Token=%{api_token}&arch=%{architecture}&flavor=%{flavor}" % {
      api_token: api_token,
      architecture: node['ID-MonitoringAgents']['oneagent']['windows']['download_params']['architecture'],
      flavor: node['ID-MonitoringAgents']['oneagent']['windows']['download_params']['flavor']
    }
    # Full URL wih parameters
    download_url = "#{node['ID-MonitoringAgents']['oneagent']['windows']['base_url']}?#{download_params}" % {
      host: node['ID-MonitoringAgents']['oneagent']['windows']['host']
    }

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "download-oneagent" do
      source download_url
      path "#{tmp_directory}\\#{oneagent_filename}"
      action :create
    end
    
  else
    # then Download from Nexus
    nexus_credentials = get_nexus_credentials
    encoded_basic_auth = encode_basic_auth_credentials nexus_credentials
    nexus_host = node['ID-ServiceDeliveryHelper']['repository']['base_url']
    nexus_path = "sd-raw-hosted-application/agents/dynatrace/Dynatrace-OneAgent-Windows-#{oneagent_version}.zip"
    # Full URL
    download_url = "#{nexus_host}/#{nexus_path}"

    Chef::Log.info("download_url: #{download_url}")
    Chef::Log.info("oneagent_filename: #{oneagent_filename}")

    # Download package
    remote_file "download-oneagent" do
      source download_url
      path "#{tmp_directory}\\#{oneagent_filename}"
      headers( "Authorization"=>"Basic #{encoded_basic_auth}" )
      action :create
    end
    
  end
  
  #Non Prod Installation
  if ::File.extname("#{oneagent_filename}") == '.zip'
    # Unzip package
    powershell_script "unzip-#{oneagent_filename}" do
      cwd tmp_directory
      code <<-EOH
        Expand-Archive "#{tmp_directory}\\#{oneagent_filename}" "#{tmp_directory}\\."
      EOH
      only_if { ::File.extname("#{oneagent_filename}") == '.zip' }
    end

    # Install package
    powershell_script 'install-oneagent' do
      cwd tmp_directory
      code <<-EOH
      . "#{tmp_directory}\\install.bat"
      EOH
    end
	
  #Prod Installation	
  else
    # unpack-msi installer
    powershell_script "unpack-msi-#{oneagent_filename}" do
      cwd tmp_directory
      code <<-EOH
        #{tmp_directory}\\#{oneagent_filename} --unpack-msi --quiet
      EOH
      only_if { ::File.extname("#{oneagent_filename}") == '.exe' }
    end

    # Install package
    powershell_script 'install-oneagent' do
      cwd tmp_directory
      code <<-EOH
        #{tmp_directory}\\install.bat /qn
      EOH
    end
  end
end
