#
# Cookbook:: ID-MonitoringAgents
# Recipe:: InstallNodeExporter
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

#============== NodeExporter ===================
# Install Prometheus node_exporter agen

case node['platform_family']
when 'debian'

  node_exporter_filename = node['ID-MonitoringAgents']['node_exporter']['debian']['filename'] % {
    version: node['ID-MonitoringAgents']['node_exporter']['debian']['version'],
    architecture: node['ID-MonitoringAgents']['node_exporter']['debian']['architecture']
  }
  node_exporter_dir = node_exporter_filename.gsub(".tar.gz","")
  Chef::Log.info("node_exporter_filename: #{node_exporter_filename}")
  Chef::Log.info("node_exporter_dir: #{node_exporter_dir}")
  node_exporter_port = node['ID-MonitoringAgents']['node_exporter']['debian']['port']

  # Open port on iptables
  open_iptables_port [node_exporter_port]

  remote_file "/tmp/#{node_exporter_filename}" do
    source node['ID-MonitoringAgents']['node_exporter']['debian']['download_url'] % {
      version: node['ID-MonitoringAgents']['node_exporter']['debian']['version'],
      base_url: node['ID-MonitoringAgents']['node_exporter']['debian']['base_url'],
      filename: node_exporter_filename
    }
    action :create
  end

  bash "unzip-and-cp-node-exporter" do
    cwd '/tmp/'
    code <<-EOH
      tar xvfz #{node_exporter_filename}
      /bin/cp -f #{node_exporter_dir}/node_exporter /usr/bin/node_exporter
    EOH
  end

  systemd_unit 'node-exporter.service' do
    content({Unit: {
              Description: 'Prometheus Node Exporter Agent'
            },
            Service: {
              ExecStart: "/usr/bin/node_exporter --web.listen-address=:#{node_exporter_port}",
              Restart: 'always',
            },
            Install: {
              WantedBy: 'multi-user.target',
            }})
    action [:create, :enable, :restart]
  end

when 'rhel'

  node_exporter_filename = node['ID-MonitoringAgents']['node_exporter']['rhel']['filename'] % {
    version: node['ID-MonitoringAgents']['node_exporter']['rhel']['version'],
    architecture: node['ID-MonitoringAgents']['node_exporter']['rhel']['architecture']
  }
  node_exporter_dir = node_exporter_filename.gsub(".tar.gz","")
  Chef::Log.info("node_exporter_filename: #{node_exporter_filename}")
  Chef::Log.info("node_exporter_dir: #{node_exporter_dir}")
  node_exporter_port = node['ID-MonitoringAgents']['node_exporter']['rhel']['port']

  # Open port on iptables
  open_iptables_port [node_exporter_port]

  # Download package
  remote_file "/tmp/#{node_exporter_filename}" do
    source node['ID-MonitoringAgents']['node_exporter']['rhel']['download_url'] % {
      version: node['ID-MonitoringAgents']['node_exporter']['rhel']['version'],
      base_url: node['ID-MonitoringAgents']['node_exporter']['rhel']['base_url'],
      filename: node_exporter_filename
    }
    action :create
  end

  # Unzip package
  bash "unzip-and-cp-node-exporter" do
    cwd '/tmp/'
    code <<-EOH
      tar xvfz #{node_exporter_filename}
      /bin/cp -f #{node_exporter_dir}/node_exporter /usr/bin/node_exporter
    EOH
  end

  # Run node_exporter as a service
  systemd_unit 'node-exporter.service' do
    content({Unit: {
              Description: 'Prometheus Node Exporter Agent'
            },
            Service: {
              ExecStart: "/usr/bin/node_exporter --web.listen-address=:#{node_exporter_port}",
              Restart: 'always',
            },
            Install: {
              WantedBy: 'multi-user.target',
            }})
    action [:create, :enable, :restart]
  end

when 'windows'
  # Windows equivalent for node_exporter is wmi_exporter

  # Create temp dir if not exists
  tmp_directory = "C:\\temp"
  directory "create-temp-dir" do
    path tmp_directory
  end

  wmi_exporter_filename = node['ID-MonitoringAgents']['wmi_exporter']['windows']['filename'] % {
    version: node['ID-MonitoringAgents']['wmi_exporter']['windows']['version'],
    architecture: node['ID-MonitoringAgents']['wmi_exporter']['windows']['architecture']
  }
  wmi_exporter_dl_path = "C:\\temp\\#{wmi_exporter_filename}"

  # Download msi file
  remote_file wmi_exporter_dl_path do
    source node['ID-MonitoringAgents']['wmi_exporter']['windows']['download_url'] % {
      version: node['ID-MonitoringAgents']['wmi_exporter']['windows']['version'],
      base_url: node['ID-MonitoringAgents']['wmi_exporter']['windows']['base_url'],
      filename: wmi_exporter_filename
    }
    action :create
  end

  # Start installation
  powershell_script 'install-wmi-exporter' do
    code <<-EOH
    . "#{wmi_exporter_dl_path}"
    EOH
  end

end
