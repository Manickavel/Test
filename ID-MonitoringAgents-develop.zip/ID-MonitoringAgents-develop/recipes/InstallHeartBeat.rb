#
# Cookbook:: ID-MonitoringAgents
# Recipe:: InstallHeartBeat
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

#============== Heartbeat ===================
# Install HeartBeat

include_recipe '::SetupMonitoring'

case node['platform_family']
when 'debian'

  apt_package "heartbeat" do
    version node['ID-MonitoringAgents']['heartbeat']['debian']['version']
    action :install
  end

  service "heartbeat" do
    action [:enable]
  end

when 'rhel'
  yum_package "heartbeat" do
    version node['ID-MonitoringAgents']['heartbeat']['rhel']['version']
    action :install
  end

  service "heartbeat" do
    action [:enable]
  end

when 'windows'

  tmp_directory = "C:\\temp"

  directory "create-temp-directory" do
   path tmp_directory
  end

  heartbeat_filename = node['ID-MonitoringAgents']['heartbeat']['windows']['filename'] % {
    version: node['ID-MonitoringAgents']['heartbeat']['windows']['version'],
    architecture: node['ID-MonitoringAgents']['heartbeat']['windows']['architecture']
  }
  heartbeat_dl_path = "C:\\temp\\#{heartbeat_filename}"
  remote_file heartbeat_dl_path do
    source node['ID-MonitoringAgents']['heartbeat']['windows']['download_url'] % {
      base_url: node['ID-MonitoringAgents']['heartbeat']['windows']['base_url'],
      filename: heartbeat_filename
    }
    action :create
  end

  heartbeat_program_path = "C:\\Program Files\\Heartbeat"

  directory "create-program-files-directory-for-heartbeat" do
   path heartbeat_program_path
  end

  powershell_script "unzip-file-#{heartbeat_filename}" do
    code <<-EOH
    expand-Archive "#{heartbeat_dl_path}" "#{tmp_directory}"
    EOH
    only_if { ::File.extname("#{heartbeat_dl_path}") == '.zip' }
  end

  powershell_script "unzip-file-#{heartbeat_filename}" do
    code <<-EOH
     move-Item -Path "#{tmp_directory}\\#{heartbeat_filename.gsub(".zip","")}\\*" -Destination "#{heartbeat_program_path}"
     EOH
     only_if { ::Dir.empty?("#{heartbeat_program_path}") }
  end

  #ExecutionPolicy UnRestricted -File "#{heartbeat_program_path}\install-service-heartbeat.ps1"
  powershell_script 'install-heartbeat' do
    code <<-EOH
    . "#{heartbeat_program_path}\\install-service-heartbeat.ps1"
    EOH
    only_if { ::File.exist?("#{heartbeat_program_path}\\install-service-heartbeat.ps1") }
  end

end
