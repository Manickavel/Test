#
# Cookbook:: ID-MonitoringAgents
# Recipe:: InstallFileBeat
#
# Copyright:: 2018, Inmarsat, All Rights Reserved.

#============== Filebeat ===================
# Install Filebeat

include_recipe '::SetupMonitoring'
::Chef::Recipe.send(:include, Chef::Mixin::PowershellOut)

case node['platform_family']
when 'debian'

  apt_package "filebeat" do
    version node['ID-MonitoringAgents']['filebeat']['debian']['version']
    action :install
  end

  service "filebeat" do
    action [:enable]
  end

when 'rhel'
  yum_package "filebeat" do
    version node['ID-MonitoringAgents']['filebeat']['rhel']['version']
    action :install
  end

  service "filebeat" do
    action [:enable]
  end

when 'windows'

  tmp_directory = "C:\\temp"

  directory "create-temp-directory" do
    path tmp_directory
  end

  filebeat_filename = node['ID-MonitoringAgents']['filebeat']['windows']['filename'] % {
    version: node['ID-MonitoringAgents']['filebeat']['windows']['version'],
    architecture: node['ID-MonitoringAgents']['filebeat']['windows']['architecture']
  }
  filebeat_dl_path = "C:\\temp\\#{filebeat_filename}"
  remote_file filebeat_dl_path do
    source node['ID-MonitoringAgents']['filebeat']['windows']['download_url'] % {
      base_url: node['ID-MonitoringAgents']['filebeat']['windows']['base_url'],
      filename: filebeat_filename
    }
    action :create_if_missing
  end

  filebeat_program_path = "C:\\Program Files\\Filebeat"

  directory "create-program-files-directory-for-filebeat" do
    path filebeat_program_path
  end.run_action(:create)

  powershell_script "unzip-file-#{filebeat_filename}" do
    code <<-EOH
     Expand-Archive -Force "#{filebeat_dl_path}" "#{tmp_directory}"
     EOH
    only_if { ::File.extname("#{filebeat_dl_path}") == '.zip' }
  end

  check_filebeat_install_script = <<-EOH
    $directoryInfo = Get-ChildItem -Path "#{filebeat_program_path}" | Measure-Object
    Write-Host $directoryInfo.count
  EOH

  filebeat_install_status = powershell_out(check_filebeat_install_script).stdout.strip!

  log 'filebeat-install-status' do
    message "Filebeat install status #{filebeat_install_status}."
    level :info
  end

  case filebeat_install_status
  when '0', '1'

    log 'first-install-of-filebeat' do
      message "Target directory (#{filebeat_program_path}) for filebeat is empty. Mostlikely a new install."
      level :info
      only_if { ::Dir.empty?("#{filebeat_program_path}") }
    end

    powershell_script "unzip-file-#{filebeat_filename}" do
      code <<-EOH
        Move-Item -Force -Path "#{tmp_directory}\\#{filebeat_filename.gsub(".zip","")}\\*" -Destination "#{filebeat_program_path}"
      EOH
    end

  else

    log 'upgrade-of-filebeat' do
      message "Target directory (#{filebeat_program_path}) for filebeat is not empty. Performing upgrade..."
      level :warn
    end

    filebeat_data_backup_path = "C:\\temp\\filebeat_backup"

    directory "create-data-backup-directory-for-filebeat" do
      path filebeat_data_backup_path
    end.run_action(:create)

    # Stop Filebeat service
    service 'filebeat' do
      action [:stop]
    end

    # Copy Filebeat data folder
    powershell_script "copy-filebeat-data-directory" do
      code <<-EOH
        Copy-Item -Recurse -Force -Path "#{filebeat_program_path}\\data" -Destination "#{filebeat_data_backup_path}\\"
      EOH
      only_if { ::Dir.exist?("#{filebeat_data_backup_path}") && !(::Dir.empty?("#{filebeat_data_backup_path}")) }
    end

    # Uninstall Filebeat
    powershell_script 'uninstall-filebeat' do
      code <<-EOH
        . "#{filebeat_program_path}\\uninstall-service-filebeat.ps1"
        Remove-Item  -Recurse -Force "#{filebeat_program_path}\\*"
      EOH
      only_if { ::File.exist?("#{filebeat_program_path}\\uninstall-service-filebeat.ps1") }
    end

    powershell_script "unzip-file-#{filebeat_filename}" do
      code <<-EOH
         Move-Item -Force -Path "#{tmp_directory}\\#{filebeat_filename.gsub(".zip","")}\\*" -Destination "#{filebeat_program_path}"
       EOH
       only_if { ::Dir.exist?("#{filebeat_program_path}") }
    end

    # Copy Filebeat data folder back to install directory
    powershell_script "copy-filebeat-data-directory" do
      code <<-EOH
         Copy-Item -Recurse -Force -Path "#{filebeat_data_backup_path}\\data" -Destination "#{filebeat_program_path}\\"
       EOH
       only_if { ::Dir.exist?("#{filebeat_data_backup_path}\\data") }
    end

  end

  # ExecutionPolicy UnRestricted -File "#{filebeat_program_path}\install-service-filebeat.ps1"
  powershell_script 'install-filebeat' do
    code <<-EOH
      . "#{filebeat_program_path}\\install-service-filebeat.ps1"
    EOH
    only_if { ::File.exist?("#{filebeat_program_path}\\install-service-filebeat.ps1") }
  end

  powershell_script "remove-unzipped-folder" do
    code <<-EOH
       Remove-Item -Force -Recurse -Path "#{tmp_directory}\\#{filebeat_filename.gsub(".zip","")}"
     EOH
     only_if { ::File.exist?("#{tmp_directory}\\#{filebeat_filename.gsub(".zip","")}") }
  end

  powershell_script "remove-unnecessary-data-backup-folder" do
    code <<-EOH
       Remove-Item -Force -Recurse -Path "#{filebeat_data_backup_path}\\"
     EOH
     only_if { ::Dir.exist?("#{filebeat_data_backup_path}") }
  end

  # Enable/Start Filebeat service
  service 'filebeat' do
    action [:enable, :start]
  end

end
