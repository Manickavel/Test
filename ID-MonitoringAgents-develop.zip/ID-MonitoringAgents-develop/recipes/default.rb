#
# Cookbook:: ID-MonitoringAgents
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

include_recipe "::SetupMonitoring"
include_recipe "::InstallNodeExporter"
