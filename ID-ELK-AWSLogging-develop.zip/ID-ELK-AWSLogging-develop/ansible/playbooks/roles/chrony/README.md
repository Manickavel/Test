Role Name
=========

Configures the system to use Chrony for network time synchronization.

Requirements
------------

Requires that the system be registered with Katello first in order to retrieve packages

Role Variables
--------------

None

Dependencies
------------

None

Example Playbook
----------------

    - hosts: all
      roles:
         - role: chrony
