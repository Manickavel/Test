Role Name
=========

Simple static role to create the standard login banner in sshd.

Requirements
------------

A linux system

Role Variables
--------------

None

Dependencies
------------

None

Example Playbook
----------------

    - hosts: all
      roles:
         - role: banners

License
-------

BSD
