Role Name
=========

Configures the hostname and hosts file for a linux system

Requirements
------------

None

Role Variables
--------------

hostnamne_name:  The hostname to be set on the instance.

Dependencies
------------

None

Example Playbook
----------------

    - hosts: all
      roles:
         - { role: hostname-linux, hostname_name: a01a00exmpll001 }
