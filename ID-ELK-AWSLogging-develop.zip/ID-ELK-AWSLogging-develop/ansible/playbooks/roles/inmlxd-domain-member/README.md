Role Name
=========

Joins the host to the inmlxd domain.

Requirements
------------

The ipaclient_enroll_pass and ipaclient_enroll_user variables must be set.  The default values will not permit the system to join the domain.

Role Variables
--------------

ipaclient_enroll_user:  Username of an account that has rights to add machines to the domain
ipaclient_enroll_pass:  The password of the aforementioned account
ipaclient_force_join:   If set to true, the role will attempt to join the domain even if the host is already joined (default: false)
ipaclient_nameservers:  Set this to override the default list of nameservers


Dependencies
------------

The host should already be registered with katello and able to retrieve packages.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: inmlxd-domain-member, ipaclient_enroll_user: superadminuser, ipaclient_enroll_pass: 123456 }
