# ID-ELK-AWSLogging
ELK Stack for logging of AWS Instances
